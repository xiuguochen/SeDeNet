import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from utils import Dataset_SAXS,interpolate_bad_points,Normalize,setup_seed,rotate_image,generate_mask_pair,generate_subimages,validation_set,PowerTransform,Denormalize
from Network_unet import UNet
from Network_rdn import RDN
from Network_rcan import RCAN
from torch.optim import lr_scheduler
import numpy as np
import time
import argparse
import datetime
import os
import torchvision.transforms as transforms
from PIL import Image


timeall = 0
parser = argparse.ArgumentParser()
parser.add_argument("--Loss_function", type=str, default="L2_loss")
parser.add_argument("--Network", type=str, default="U-net")
parser.add_argument('--train_dir', type=str, default="train_set")
parser.add_argument('--val_dir', type=str, default="test_set/1-D grating_labSAX")
parser.add_argument('--save_model_path', type=str, default='./Model')
parser.add_argument('--save_result_path', type=str, default='./Result')
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--predict_num', type=int, default=2)
parser.add_argument('--sigma', type=float, default=0.1)
parser.add_argument('--ratio', type=float, default=1.0)
parser.add_argument('--num_epoch', type=int, default=100)
parser.add_argument('--num_seed', type=int, default=21)
parser.add_argument('--n_snapshot', type=int, default=1)
parser.add_argument('--batchsize', type=int, default=128, help='RDN:32,Unet:128')
parser.add_argument("--power", type=float, default=0.6)
parser.add_argument("--valid_power", type=float, default=0.5)


opt, _ = parser.parse_known_args()
systime = datetime.datetime.now().strftime('%Y%m%d')

def check(net, epoch,Network,Loss_function):
    seed_name = 'seed_{:02d}'.format(opt.num_seed)
    lr_name = 'lr_{:.4f}'.format(opt.lr)
    save_model_path = os.path.join(opt.save_model_path,systime,Network,Loss_function,seed_name,lr_name)
    os.makedirs(save_model_path, exist_ok=True)
    model_name = 'epoch_{:03d}_lr_{:.4f}_power_{:.02f}.pth'.format (epoch,opt.lr,opt.power)
    save_model_path = os.path.join(save_model_path, model_name)
    torch.save(net.state_dict(), save_model_path)
    print('Model saved to {}'.format(save_model_path))

setup_seed(opt.num_seed)

device = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")

valid_noisy = os.path.join(opt.val_dir)

Dataset = Dataset_SAXS(opt.train_dir)
valid_img,H,W,filenames = validation_set(valid_noisy)

Train_loader = DataLoader(dataset=Dataset, batch_size=opt.batchsize, shuffle=True, drop_last=False, pin_memory=False)

net = UNet()
# net = RDN()
# net = RCAN()

net = net.to(device)
optimizer = optim.AdamW(net.parameters(), lr=opt.lr)
shceduler = lr_scheduler.MultiStepLR(optimizer, milestones=[
                                         int(20 * opt.ratio) - 1,
                                         int(40 * opt.ratio) - 1,
                                         int(60 * opt.ratio) - 1,
                                         int(80 * opt.ratio) - 1,

                                     ], gamma=opt.sigma)

for epoch in range(1,opt.num_epoch+1):
    for param_group in optimizer.param_groups:
        current_lr = param_group['lr']
    print("LearningRate of Epoch {} = {}".format(epoch, current_lr))

    net.train()
    start = time.time()
    for iteration, noise_img in enumerate(Train_loader):

        optimizer.zero_grad()
        noise_img = interpolate_bad_points(noise_img)
        noise_img = rotate_image(noise_img)
        noise_img = torch.pow(noise_img,opt.power)

        noise_img, max,min = Normalize(noise_img)

        noise_img = noise_img.to(device)

        optimizer.zero_grad()

        mask1, mask2 = generate_mask_pair(noise_img)
        subimage1 = generate_subimages(noise_img, mask1)
        subimage2 = generate_subimages(noise_img, mask2)

        with torch.no_grad():
            noise_img_denoised = net(noise_img)

        subimage1_denosied = generate_subimages(noise_img_denoised, mask1)
        subimage2_denosied = generate_subimages(noise_img_denoised, mask2)
        output = net(subimage1)
        target = subimage2

        '''L2 loss'''
        loss = nn.MSELoss()
        loss = loss(output, target)


        loss.backward()
        optimizer.step()

    end = time.time()
    total = end - start
    timeall = total + timeall

    print('epoch={:03d} L2 Loss={:.6f} , Time={:.2f} s'.format(epoch, np.mean(loss.item()), end - start))
    shceduler.step()

    if epoch % opt.n_snapshot == 0 or epoch == opt.num_epoch:

        net.eval()
        check(net, epoch,opt.Network,opt.Loss_function)
        for idx, noisy in enumerate(valid_img):

            transformer = transforms.Compose([transforms.ToTensor()])
            noisy = transformer(noisy)
            noisy_img = torch.unsqueeze(noisy, 0).to(device)
            noisy_img = interpolate_bad_points(noisy_img)
            img = PowerTransform(noisy_img, opt.valid_power)
            img, max, min = Normalize(img)

            for i in range(opt.predict_num):
                with torch.no_grad():
                     denoised_img = net(img)
                     img =denoised_img
            output = Denormalize(denoised_img, max, min)

            output = (output ** (1 / opt.valid_power)).cpu()
            output = output[:,:,:H[idx],:W[idx]]

            epoch_num = 'epoch_{:03d}'.format(int(epoch))
            seed_name = 'seed_{:02d}'.format(opt.num_seed)
            lr_name = 'lr_{:.4f}_power_{:.02f}_valid_power_{:.02f}_pre_num_{:02d}_epoch_{:03d}_sigma_{:.01f}'.format(opt.lr,opt.power,opt.valid_power,opt.predict_num,opt.num_epoch,opt.sigma)
            save_result_path = os.path.join(opt.save_result_path, systime, opt.Network,opt.Loss_function, seed_name,lr_name, epoch_num)
            os.makedirs(save_result_path, exist_ok=True)
            result_name = 'denoised_{:03d}.tif'.format(idx+1)
            save_model_path = os.path.join(save_result_path, result_name)
            Image.fromarray(output.squeeze().to(torch.int32).numpy(), mode='I').save(
                save_model_path)

print("Training Finished! total time = {:.2f} min".format(timeall/60))

