import os
import torch.nn.functional as F
import torch
import glob
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
import numpy as np
import random

operation_seed_counter = 0


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    pass


class Dataset_SAXS(Dataset):
    def __init__(self, root_dir, transform=None):
        super(Dataset_SAXS, self).__init__()
        self.root_dir = root_dir
        self.image_dirs = glob.glob(os.path.join(self.root_dir, "*/*"))
        self.image_dirs.sort()
        print('fetch {} samples for training'.format(len(self.image_dirs)))

    def __getitem__(self, index):
        img = Image.open(self.image_dirs[index])
        img = np.array(img, dtype=np.float32)

        H = img.shape[0]
        W = img.shape[1]
        H_size = (H + 31) // 32 * 32
        W_size = (W + 31) // 32 * 32
        img = np.pad(
            img,
            [[0, H_size - H], [0, W_size - W]],
            'reflect')

        transformer = transforms.Compose([transforms.ToTensor()])
        dataset = transformer(img)
        return dataset

    def __len__(self):
        return len(self.image_dirs)


def validation_set(noise_dir):
    if os.path.isfile(noise_dir):
        noise_datas = [noise_dir]
    else:
        noise_datas = glob.glob(os.path.join(noise_dir, "*"))
        noise_datas.sort()

    noise_images = []
    H_array = []
    W_array = []
    file_names = []
    for noise in noise_datas:
        file_name = os.path.basename(noise)
        file_names.append(file_name)

        img = Image.open(noise)
        img = np.array(img, dtype=np.float32)

        H = img.shape[0]
        W = img.shape[1]
        H_array.append(H)
        W_array.append(W)

        H_size = (H + 31) // 32 * 32
        W_size = (W + 31) // 32 * 32
        img = np.pad(
            img,
            [[0, H_size - H], [0, W_size - W]],
            'reflect')

        noise_images.append(img)
    return noise_images, H_array, W_array, file_names


def interpolate_bad_points(image_tensor):
    mask = image_tensor < 0
    n, c, h, w = image_tensor.size()
    image_tensor[mask] = 0
    resized_image = F.interpolate(image_tensor, size=(h * 2, w * 2), mode='bilinear', align_corners=False)
    interpolated_image = F.interpolate(resized_image, size=(h, w), mode='bilinear', align_corners=False) * 4.5
    repaired_image = image_tensor.clone()
    repaired_image[mask] = interpolated_image[mask]
    return repaired_image


def get_generator(device):
    global operation_seed_counter
    operation_seed_counter += 1
    g_cuda_generator = torch.Generator(device=device)
    g_cuda_generator.manual_seed(operation_seed_counter)
    return g_cuda_generator


def space_to_depth(x, block_size):
    n, c, h, w = x.size()
    unfolded_x = torch.nn.functional.unfold(x, block_size, stride=block_size)
    return unfolded_x.view(n, c * block_size ** 2, h // block_size,
                           w // block_size)


def generate_mask_pair(img):
    # prepare masks (N x C x H/2 x W/2)
    n, c, h, w = img.shape
    mask1 = torch.zeros(size=(n * h // 2 * w // 2 * 4,),
                        dtype=torch.bool,
                        device=img.device)
    mask2 = torch.zeros(size=(n * h // 2 * w // 2 * 4,),
                        dtype=torch.bool,
                        device=img.device)
    # prepare random mask pairs
    idx_pair = torch.tensor(
        [[0, 1], [0, 2], [1, 3], [2, 3], [1, 0], [2, 0], [3, 1], [3, 2], [0, 3], [1, 2], [3, 0], [2, 1]],
        dtype=torch.int64,
        device=img.device)

    rd_idx = torch.zeros(size=(n * h // 2 * w // 2,),
                         dtype=torch.int64,
                         device=img.device)

    single_random_value = torch.randint(low=0, high=12, size=(1,), device=img.device,
                                        generator=get_generator(img.device)).item()
    rd_idx[:] = single_random_value
    rd_pair_idx = idx_pair[rd_idx]
    rd_pair_idx += torch.arange(start=0,
                                end=n * h // 2 * w // 2 * 4,
                                step=4,
                                dtype=torch.int64,
                                device=img.device).reshape(-1, 1)
    # get masks
    mask1[rd_pair_idx[:, 0]] = 1
    mask2[rd_pair_idx[:, 1]] = 1
    return mask1, mask2


def generate_subimages(img, mask):
    n, c, h, w = img.shape
    subimage = torch.zeros(n,
                           c,
                           h // 2,
                           w // 2,
                           dtype=img.dtype,
                           layout=img.layout,
                           device=img.device)
    # per channel
    for i in range(c):
        img_per_channel = space_to_depth(img[:, i:i + 1, :, :], block_size=2)
        img_per_channel = img_per_channel.permute(0, 2, 3, 1).reshape(-1)
        subimage[:, i:i + 1, :, :] = img_per_channel[mask].reshape(
            n, h // 2, w // 2, 1).permute(0, 3, 1, 2)
    return subimage


def rotate_image(img):
    randint = torch.randint(low=1, high=5, size=(1,), device=img.device,
                            generator=get_generator(img.device)).item()
    if randint == 1:
        img = torch.rot90(img, 1, [2, 3])
    elif randint == 2:
        img = torch.rot90(img, 2, [2, 3])
    elif randint == 3:
        img = torch.rot90(img, 3, [2, 3])
    elif randint == 4:
        img = img
    return img


def PowerTransform(img, power=0.5):
    img = img.to(torch.float32)
    img = img ** power
    return img


def Normalize(img):
    img = img.to(torch.float32)
    max = img.max()
    min = img.min()
    img = (img - min) / (max - min)
    return img, max, min


def Denormalize(img, max, min):
    img = img.to(torch.float32)
    img = img * (max - min) + min
    return img


def get_tif_files(folder_path):
    tif_files = []
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.tif', '.tiff')):
            tif_files.append(os.path.join(folder_path, filename))
    return tif_files


if __name__ == '__main__':
    dataset = Dataset_SAXS("./dataset")
    img = dataset[756].unsqueeze(0)
    mask1, mask2 = generate_mask_pair(img)
    subimage1 = torch.squeeze(generate_subimages(img, mask1)).to(torch.int32)
    subimage2 = torch.squeeze(generate_subimages(img, mask2)).to(torch.int32)
    print(subimage1.shape)
    print(img.shape)
