import torch
import torch.nn as nn
import torch.nn.init as init


def initialize_weights(net_l, scale=1.0):
    if not isinstance(net_l, list):
        net_l = [net_l]
    for net in net_l:
        for m in net.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Conv3d):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale  # for residual block
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.ConvTranspose2d) or isinstance(
                    m, nn.ConvTranspose3d):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale  # for residual block
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d) or isinstance(
                    m, nn.BatchNorm3d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias.data, 0.0)


class UNet(nn.Module):
    def __init__(self, in_channels=1, out_channels=1, num_feature=48):
        super(UNet, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_feature = num_feature

        # Encoder Part
        self.encode1 = nn.Sequential(
            nn.Conv2d(in_channels, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.Conv2d(self.num_feature, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(2))
        initialize_weights(self.encode1, 0.1)
        self.encode2 = nn.Sequential(
            nn.Conv2d(self.num_feature, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(2))
        initialize_weights(self.encode2, 0.1)
        self.encode3 = nn.Sequential(
            nn.Conv2d(self.num_feature, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(2))
        initialize_weights(self.encode3, 0.1)
        self.encode4 = nn.Sequential(
            nn.Conv2d(self.num_feature, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(2))
        initialize_weights(self.encode4, 0.1)
        self.encode5 = nn.Sequential(
            nn.Conv2d(self.num_feature, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(2))
        initialize_weights(self.encode5, 0.1)
        self.encode6 = nn.Sequential(
            nn.Conv2d(self.num_feature, self.num_feature, kernel_size=3, padding=1, stride=1, bias=False),
            nn.ConvTranspose2d(self.num_feature, self.num_feature, kernel_size=2, stride=2, padding=0, output_padding=0,
                               bias=False))
        initialize_weights(self.encode6, 0.1)

        # Decoder Part
        self.decode1 = nn.Sequential(
            nn.Conv2d(self.num_feature * 2, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(self.num_feature * 2, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ConvTranspose2d(self.num_feature * 2, self.num_feature * 2, kernel_size=2, stride=2, padding=0,
                               output_padding=0, bias=False))
        initialize_weights(self.decode1, 0.1)
        self.decode2 = nn.Sequential(
            nn.Conv2d(self.num_feature * 3, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(self.num_feature * 2, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ConvTranspose2d(self.num_feature * 2, self.num_feature * 2, kernel_size=2, stride=2, padding=0,
                               output_padding=0, bias=False))
        initialize_weights(self.decode2, 0.1)
        self.decode3 = nn.Sequential(
            nn.Conv2d(self.num_feature * 3, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(self.num_feature * 2, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ConvTranspose2d(self.num_feature * 2, self.num_feature * 2, kernel_size=2, stride=2, padding=0,
                               output_padding=0, bias=False))
        initialize_weights(self.decode3, 0.1)
        self.decode4 = nn.Sequential(
            nn.Conv2d(self.num_feature * 3, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(self.num_feature * 2, self.num_feature * 2, kernel_size=3, padding=1, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ConvTranspose2d(self.num_feature * 2, self.num_feature * 2, kernel_size=2, stride=2, padding=0,
                               output_padding=0, bias=False))
        initialize_weights(self.decode4, 0.1)
        self.decode5 = nn.Sequential(
            nn.Conv2d(self.num_feature * 2 + self.in_channels, self.num_feature * 2, kernel_size=3, padding=1, stride=1,
                      bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(self.num_feature * 2, self.num_feature * 2, kernel_size=1, padding=0, stride=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True))
        initialize_weights(self.decode5, 0.1)
        self.output_layer = nn.Conv2d(self.num_feature * 2, self.out_channels, kernel_size=1, padding=0, stride=1,
                                      bias=True)

    def forward(self, x):
        # Encoder Part
        pool1 = self.encode1(x)
        pool2 = self.encode2(pool1)
        pool3 = self.encode3(pool2)
        pool4 = self.encode4(pool3)
        pool5 = self.encode5(pool4)

        # Decoder Part
        upsample5 = self.encode6(pool5)
        upsample4 = self.decode1(torch.cat([upsample5, pool4], dim=1))
        upsample3 = self.decode2(torch.cat([upsample4, pool3], dim=1))
        upsample2 = self.decode3(torch.cat([upsample3, pool2], dim=1))
        upsample1 = self.decode4(torch.cat([upsample2, pool1], dim=1))
        upsample0 = self.decode5(torch.cat([upsample1, x], dim=1))
        output = self.output_layer(upsample0)
        return output


if __name__ == '__main__':
    x = torch.randn(5, 1, 1024, 128)
    print(x.shape)
    net = UNet()
    y = net(x)
    print(y.shape)
