import torch
from PIL import Image
import numpy as np
import torchvision.transforms as transforms
from Network_rdn import RDN
from Network_unet import UNet
from Network_rcan import RCAN
from utils import interpolate_bad_points, Denormalize, Normalize, PowerTransform,validation_set
import time
import csv
import os
import argparse



times = []
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

parser = argparse.ArgumentParser()
parser.add_argument('--power', type=float, default=0.5, help='power transform parameter')
parser.add_argument('--predic_num', type=int, default=2, help='number of predict iterations')
parser.add_argument('--testset_path', type=str, default="Simulation_data/noise_set")
parser.add_argument('--model_path', type=str, default="Model/Model_20250618.pth")
parser.add_argument('--save_path', type=str, default='./Result/Simulation_data')

opt,_ = parser.parse_known_args()

valid_img, H, W, file_names = validation_set(opt.testset_path)
os.makedirs(opt.save_path, exist_ok=True)

for idx,img in enumerate(valid_img):
    start = time.time()

    transformer = transforms.Compose([transforms.ToTensor()])
    img = transformer(img).unsqueeze(0).to(device)
    img = interpolate_bad_points(img)
    img = PowerTransform(img, opt.power)
    img, max, min = Normalize(img)

    # net = RDN()
    net = UNet()
    # net = RCAN()

    net.load_state_dict(torch.load(opt.model_path, map_location=torch.device('cuda')))
    net.to(device)
    net.eval()
    for i in range(opt.predic_num):
        with torch.no_grad():
            output = net(img)
            img = output
    output = Denormalize(output, max, min)
    output = (output ** (1 / opt.power)).cpu()
    output = output[:, :, :H[idx], :W[idx]]
    end = time.time()
    elapsed_time = end - start
    times.append((idx,elapsed_time))
    output_file_name = 'de_'+file_names[idx]

    output_file_path = os.path.join(opt.save_path, output_file_name)

    print("Time used for denoising image {:03d}: {:.4f}s".format(idx, end-start))

    ######## save the image as float type###############
    Image.fromarray(output.squeeze().to(torch.float32).numpy(), mode='F').save(output_file_path)
    ######## save the image as int type###############
    # Image.fromarray(output.squeeze().to(torch.int32).numpy(), mode='I').save(output_file_path)

csv_file_path = os.path.join(opt.save_path, 'caculate_time.csv')
with open(csv_file_path, 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["img", "Time (seconds)"])
    for v, elapsed_time in times:
        img_name = 'de_' + file_names[v]
        writer.writerow([img_name, elapsed_time])